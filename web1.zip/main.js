$(document).ready(function () {
  $('.navbar-nav li').click(function (x) {
    $('.navbar-nav li').removeClass('active');
    $(event.target).parent().addClass('active');
  });
});

function showCircuit() {
  $('#circuit').change(function (o) {
    switch (o.target.value) {
      case 'ITA':
        $('#circuitimage').attr('src', 'img/monza.jpg');
        $('#f1sound')[0].play();
        break;
      case 'HUN':
        $('#circuitimage').attr('src', 'img/hungaroring.jpg');
        break;
      case 'BEL':
        $('#circuitimage').attr('src', 'img/spa.jpg');
        break;
      case 'MON':
        $('#circuitimage').attr('src', 'img/monaco.jpg');
        break;

      default:
        break;
    }
  });
}

//---------------------------------------------------------

function calculate() {
  let map = document.querySelector('#circuit').value;
  let speed = document.querySelector('#laptime').value / 3600;

  if (map = HUN) {
    let final = 4.381 / speed
  } else if (map = MON) {
    let final = 3.337 / speed
  } else if (map = BEL) {
    let final = 7.004 / speed
  } else if (map = ITA) {
    let final = 5.793 / speed
  }
  let slot = document.querySelector('#averagespeed').innerHTML;
  slot.value = final;
}
